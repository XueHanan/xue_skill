# xue-skills 2.0

版本 2.0（2026-11-09），替代 1.0。保留 xue、xue-plus 两个显式调用入口，默认不写回原 Word。xue 侧重绪论与理论基础，xue-plus 侧重摘要、方法、系统、实验和结论；同一任务可按实际内容路由，无需因名字用错而中断。

## 2.0 变更

- `references/styles.md` 的「用户偏好」新增「已确认偏好（2026-11-09，<171> 段定稿）」：段首判断句不用“关注如何”，两项工作的区别用分号对举而不先总起加冒号，不用“对……而言”起句，不用“一并／共同考虑／统筹”压缩并列关系，保留“把”字句，“如何”按句法位置判断，叙述句少用“提示＋解释”式冒号。
- xue 与 xue-plus 的 `references/styles.md` 保持逐字节一致；两份 `SKILL.md` 增加指向「用户偏好」的一句说明。
- 除上述风格条款外，脚本、流程与校验口径与 1.0 相同，未改动。

## 安装

备份已有技能目录，再将包内 xue/ 与 xue-plus/ 替换到宿主的技能目录，避免把旧 scripts 混进新版。整目录删除后复制，不做覆盖合并；1.0 与 2.0 的 scripts 不通用。

本机安装（2026-11-09）：`<项目>/.dsh/skills/` 下的 xue、xue-plus 已由 2.0 包整体替换，替换前的旧目录备份在 `skills/_backup/2026-11-09_pre-2.0/`（相对论文项目根目录）。

- DSH：原包约定的项目目录为 `<项目>/.dsh/skills/`，全局目录为 `%USERPROFILE%/.dsh/skills/`。本次没有运行真实 DSH 会话，不承诺具体版本的发现或热重载行为；按实际宿主确认加载。
- Codex：技能目录通常为 `%USERPROFILE%/.codex/skills/`，或实际 CODEX_HOME/skills。两个技能的 agents/openai.yaml 保留显式调用策略。

两个目录各自完整，可以独立部署；推荐同时替换。DSH 是否读取 agents/openai.yaml 取决于实现；正文与 description 也明确保留点名调用约定。

## 使用

```text
用 xue 润色这一段，给原文和改后对照。
用 xue 润色论文第二章，只处理理论基础。
用 xue-plus 润色第三章方法，保留步骤、公式和参数。
```

小段文字直接处理；文件流程只需 Python 3.10+ 标准库，无需 python-docx、宿主依赖加载工具或额外润色插件。脚本详细流程见对应技能 references/workflow.md。

```text
python xue/scripts/inspect_docx.py SOURCE.docx
python xue/scripts/prepare.py SOURCE.docx TASK --range START END --mode theory --term 溺水人员检测
```

DOCX 必须明确范围，或在用户授权全文处理时加 --whole-document；段号从0开始。纯文本文件可直接 prepare。修改 TASK/comparison.md 后：

```text
python xue/scripts/review_template.py TASK/comparison.md TASK
python xue/scripts/validate.py TASK/comparison.md TASK
```

review_template 只生成待复核记录，不自动签署。代理逐段完成五项语义检查，填写具体依据后再验证。0=通过，1=失败，2=待复核；不能把待复核报告成通过。语义记录绑定具体文本版本，仍不等于对技术正确性的证明。

按用户要求，已移除原始论文文件的 SHA-256 计算、保存和校验。任务只使用提取基线；更换论文版本后重新准备。内部摘要仅用于提取产物和修订/复核记录的版本关联，不验证原始论文文件。

## 与原包的主要变化

- 统一校验范围、空内容、原文、唯一公式标记、数字/单位、术语、变量、图表引用和语义复核状态。
- 支持 OMML 和可识别的 Equation/MathType OLE；其他复杂对象、Word 域及未接受的修订保守冻结。表格只读，不声称覆盖所有 Word 区域。
- 引用及数值归属变化不能只靠集合判断；修改段必须有具体语义复核依据。
- 附录和统计从最终版本自动生成，不再手写表格后用不匹配的解析器验证。
- 取消固定句长、连接词配额、禁用正常技术用词和自评分数门槛；可选参考论文不再成为隐含前置条件。
- 不要求先勾选所有修改，不固定进行多轮润色；任何正文变更均重新完成适用复核和统一验证。

旧版 lint_md.py、compose_revised.py、stats.py、check_appendix.py、check_polish.py、check_refs.py 的分散命令已由 validate.py 取代。extract_docx.py 是 prepare.py 的别名，verify_md.py 是 validate.py 的别名；旧 paragraphs.json 不能直接当新版任务使用，应重新提取。旧 [M] 不具唯一身份，需要回原文件重新准备。
